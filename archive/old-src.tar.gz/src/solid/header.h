#ifndef header_solid_h
#define header_solid_h

#include <boost/regex.hpp>
#include "utils.h"
#include "types.h"
#include "params.h"
#include "interpolation.h"
#include "dataanalysis.h"
#include "dirList.h"

using std::vector;
using std::map;
using std::set;
using boost::regex;
using namespace alglib;

const regex re_phone("\\d{3}(-|\\s)*\\d{3}-\\d{4}");
class StrUtils {
public:
  static int numlines(const string fname) {
    FileHandler fin(fname, std::ios::in);
    string line;
    int num(0);
    while(getline(fin, line)) 
      ++num;
    fin.close();
    return num;
  }
  static bool containsKeyword(const string& snt) {
    static set<string> keywords_;
    if(keywords_.size() == 0)  {
      keywords_.insert("nonfarm");
      keywords_.insert("economy");
      keywords_.insert("employment");
    }
    iterate(keywords_, kit) {
      if(snt.find(*kit) != string::npos) {
        return true;
      }
    }
    return false;
  }
  static bool pruneSnts(const string& snt, const vector<word_t>& vw) {
    if(
      //(!containsKeyword(snt)) ||
      (snt.size() < 15) || (vw.size() > 200) || 
      (find(vw.begin(), vw.end(), "|") != vw.end()) ||
      ((vw.back().size() > 1) && (vw.back() != "...")) || 
      (vw[0] == "Copyright") || (vw[0] == "IPD") || (vw[0] == "RF") ||
      (vw[0] == "IN") || (vw[0] == "PUB") || (vw[0] == "HD") || 
      (vw[0] == "HT") || (vw[0] == "BY") || (vw[0] == "SE") ||
      (vw[0] == "AN") || (vw[0] == "WC") ||
      (find(vw.begin(), vw.end(), "http") != vw.end()) ||
      (find(vw.begin(), vw.end(), "/") != vw.end()) ||
      (snt.find("www.") != string::npos) ||
      (snt.find("@") != string::npos) ||
      (snt.find("©") != string::npos) ||
      regex_search(snt, re_phone) ||  
      (Utils::lowercase(snt) == "all rights reserved .") || 
      (Utils::lowercase(snt) == "the associated press .") ||
      (Utils::lowercase(snt) == "market news international , inc .") ||
      (vw[0] == "=" && vw.back() == "=") 
      ){
        return true;
    }
    return false;
  }
  static bool pruneWord(word_t& wrd) {
    if((wrd == "\"") || (wrd == "TD") || (wrd == "=") 
      || (wrd == "\"")
    ){
        return true;
    }
    if(wrd == "--") wrd = "-";
    return false;
  }
};
#endif
