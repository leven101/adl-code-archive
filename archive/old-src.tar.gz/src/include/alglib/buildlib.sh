g++ -c *.cpp
ar rvs libalglib.a *.o
